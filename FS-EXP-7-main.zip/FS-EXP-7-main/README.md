# FS-EXP-7
This repo consist of experiments performed under Full Stack Integration Section. 

## FS Full Stack Integration Proofs

## Practice 1
<img src="/Assests/Practice-1.png" alt="Practice-1 Proof">

## Practice 1
<img src="/Assests/Practice-2.png" alt="Practice-2 Proof">

## Practice 1
<img src="/Assests/Practice-3.png" alt="Practice-3 Proof">